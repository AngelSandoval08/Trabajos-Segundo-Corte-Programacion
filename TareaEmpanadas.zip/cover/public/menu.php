<header class="mb-auto">
    <div>
      <h3 class="float-md-start mb-0">Cafetería ITFIP</h3>
      <nav class="nav nav-masthead justify-content-center float-md-end">
        <a class="nav-link fw-bold py-1 px-0 " aria-current="page" href="index.php">Inicio</a>
        <a class="nav-link fw-bold py-1 px-0" href="comprar.php">Comprar</a>
        <a class="nav-link fw-bold py-1 px-0" href="caf_menu.php">Menú</a>
      </nav>
    </div>
  </header>