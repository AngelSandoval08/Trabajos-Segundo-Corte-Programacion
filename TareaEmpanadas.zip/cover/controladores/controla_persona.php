<?php
if (isset($_POST["val_pagar"]) && isset($_POST["edad"]) ) 
{

    $total_pagar = $_POST["val_pagar"];

    $edad = $_POST["edad"];
    
    $descuento = $total_pagar * 0.20;
    
    $des_total = $total_pagar - $descuento;
    
    if( $edad > 60 ){
    
        echo "El total a pagar con descuento del 20% es de: ". $des_total;
    
    }else{
    
       echo "El total a pagar es de: ". $total_pagar;
    
    }

    
} else {
    
}



?>