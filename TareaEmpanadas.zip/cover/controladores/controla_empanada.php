<?php

if (isset($_POST['num_empanada'])) {

    $num_empanada = $_POST['num_empanada'];

    $venta_total = $num_empanada * 2000;

    // Crear un formulario automático que envía los datos a comprar.php

    echo '<form id="autoform" action="../public/comprar.php" method="POST">';
    echo '<input type="hidden" name="num_empanada" value="' . htmlspecialchars($num_empanada) . '">';
    echo '<input type="hidden" name="venta" value="' . htmlspecialchars($venta_total) . '">';
    echo '</form>';
    echo '<script>document.getElementById("autoform").submit();</script>';
} else {
    echo "Error: No se recibió el número de empanadas.";
}



$total_empanada = $_POST["num_empanada"];

$venta_total = $total_empanada * 2000;

if($total_empanada>1){

    echo "El valor total de sus ". $total_empanada . " empanadas, es de: ". $venta_total ." pesos.";

}else{

echo "El valor total de su empanada, es de: ". $venta_total ." pesos.";

} 



?>