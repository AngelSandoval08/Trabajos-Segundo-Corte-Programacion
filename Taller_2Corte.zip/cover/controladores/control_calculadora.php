<?php

$num1 = $_POST["numero1"];
$num2 = $_POST["numero2"];
$operacion = $_POST["operacion"];

if ($operacion == 1 ) {
   $suma = $num1 + $num2;
    echo "La suma de sus valores es ". $suma;
    }
if ($operacion == 2 ) {
    $resta = $num1 - $num2;
     echo "La resta de sus valores es ". $resta;
    }
   
if ($operacion == 3 ) {
    $multi = $num1 * $num2;
     echo "La multiplicacion de sus valores es ". $multi;
 } 

if ($operacion == 4 ) {
   
    if ($num1> 0 && $num2 > 0) {
        $div = $num1 / $num2;

        if ($div > 0) {
           
             echo "La division de sus valores es ". $div;
           }
           else {
                echo "Error";
            }
     }
     else {
        echo "Error";
    }
    }


