<?php
$des= $_POST['descripcion'];
$venta= $_POST['venta'];

if ($venta > 0) {
    
    echo ("Descripcion de la venta:  ".$des.
    " <br> Valor total: ".$venta);
}

else{
    echo ("Error");
}