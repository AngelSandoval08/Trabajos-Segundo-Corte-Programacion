<?php
$nombre= $_POST['nombre'];
$doc= $_POST['documento'];
$edad= $_POST['edad'];


if ($edad >= 18) {
    
    echo ("Usuario registrado: <br> <br>
    Nombre: ".$nombre." <br>
    Numero de documento: ".$doc.
    " <br> Edad: ".$edad);
}

else{
    echo ("Error");
}

